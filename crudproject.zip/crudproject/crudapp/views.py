from django.http import HttpResponse, HttpResponseRedirect
import random
import string
from django.shortcuts import render
from .models import student_frm
from .forms import formclass
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout
from .forms import SignUpForm

def show_data(request):
    if request.method == 'POST':
        fm = formclass(request.POST)
        if fm.is_valid():
            adhar_no = int(''.join(random.choice(string.digits) for n in range(10)))
            name = fm.cleaned_data['name']
            fname = fm.cleaned_data['fname']
            age = fm.cleaned_data['age']
            gender = fm.cleaned_data['gender']
            date_brth = fm.cleaned_data['date_brth']
            email = fm.cleaned_data['email']
            address = fm.cleaned_data['address']
            phone_no = fm.cleaned_data['phone_no']
            reg = student_frm(adhar_no =adhar_no,name= name,fname= fname,age=age,gender=gender, date_brth= date_brth,email=email,address=address,phone_no=phone_no,)
            reg.save()
            fm = formclass()
    else:
        fm = formclass()
    return render(request, 'index.html',{'forms':fm,'data':student_frm.objects.all()})

def update_data(request,id):
        pi = student_frm.objects.get(pk=id)
        fm = formclass(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
        else:
            pi = student_frm.objects.get(pk=id)
            fm = formclass(instance=pi)
        return render(request,'index.html',{'forms':fm})

def delete_data(request,id):

    if request.method == 'POST':
        pi = student_frm.objects.get(pk = id)
        print(pi)
        pi.delete()
        return HttpResponseRedirect('/show_data')


def sign_up(request):
    if request.method == 'POST':
        fm = SignUpForm(request.POST)
        if fm.is_valid():
            messages.success(request,"created Done")
            fm.save()
    else:
        fm =SignUpForm()
    return render(request,'signup.html',{'form':fm})


def user_login(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            fm = AuthenticationForm(request=request, data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    login(request, user)
                    messages.success(request, 'Logged in Succesfully !!!')
                    return HttpResponseRedirect('show_data')
        else:
            fm = AuthenticationForm()
            return render(request, 'login.html', {'form': fm})
    else:
        return HttpResponseRedirect('user_login')

def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/user_login')