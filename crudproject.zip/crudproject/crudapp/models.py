from django.db import models

class student_frm(models.Model):
    adhar_no = models.IntegerField(null=True)
    name = models.CharField(max_length =10,null=True)
    fname = models.CharField(max_length =10,null=True)
    age = models.IntegerField(null=True)
    gender = models.CharField(max_length =10,null=True)
    date_brth = models.DateField(null=True)
    email = models.EmailField(null=True)
    address = models.CharField(max_length =50,null=True)
    phone_no = models.IntegerField(null=True)