from django.contrib import admin
from .models import student_frm
# Register your models here.
@admin.register(student_frm)
class Show(admin.ModelAdmin):
    list_display = ['id','adhar_no','name','fname','age','gender','date_brth','email','address','phone_no']
